// init.js

// Function to generate ObjectId
function generateObjectId() {
    return ObjectId().toString();
}

// Create database 'core'
db = db.getSiblingDB('mrswriter');

// Create collection 'User'
db.createCollection('Notes');

// Insert a document into the 'User' collection
db.Notes.insertOne({
    title:"Dominica",
    description: "HelloTata",
    jsonFileName: "testFile.json",
    id_user:"0"
});
db.Notes.insertOne({
    title:"Jane",
    description: "HelloTata",
    jsonFileName: "testFile.json",
    id_user:"0"
});

